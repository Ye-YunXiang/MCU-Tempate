var searchData=
[
  ['i_2dcache_20functions',['I-Cache Functions',['../group__Icache__functions__m7.html',1,'']]],
  ['intrinsic_20functions_20for_20cpu_20instructions',['Intrinsic Functions for CPU Instructions',['../group__intrinsic__CPU__gr.html',1,'']]],
  ['intrinsic_20functions_20for_20simd_20instructions_20_5bonly_20cortex_2dm4_20and_20cortex_2dm7_5d',['Intrinsic Functions for SIMD Instructions [only Cortex-M4 and Cortex-M7]',['../group__intrinsic__SIMD__gr.html',1,'']]],
  ['interrupts_20and_20exceptions_20_28nvic_29',['Interrupts and Exceptions (NVIC)',['../group__NVIC__gr.html',1,'']]]
];
