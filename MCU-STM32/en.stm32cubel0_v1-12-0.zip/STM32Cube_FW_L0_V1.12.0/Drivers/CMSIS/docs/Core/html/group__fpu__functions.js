var group__fpu__functions =
[
    [ "SCB_GetFPUType", "group__fpu__functions.html#ga6bcad99ce80a0e7e4ddc6f2379081756", null ]
];