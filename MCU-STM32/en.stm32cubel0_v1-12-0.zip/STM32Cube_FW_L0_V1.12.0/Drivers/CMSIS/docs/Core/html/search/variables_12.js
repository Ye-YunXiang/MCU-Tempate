var searchData=
[
  ['v',['V',['../unionAPSR__Type.html#a8004d224aacb78ca37774c35f9156e7e',1,'APSR_Type::V()'],['../unionxPSR__Type.html#af14df16ea0690070c45b95f2116b7a0a',1,'xPSR_Type::V()']]],
  ['val',['VAL',['../structSysTick__Type.html#a9b5420d17e8e43104ddd4ae5a610af93',1,'SysTick_Type']]],
  ['vtor',['VTOR',['../structSCB__Type.html#a187a4578e920544ed967f98020fb8170',1,'SCB_Type']]]
];
