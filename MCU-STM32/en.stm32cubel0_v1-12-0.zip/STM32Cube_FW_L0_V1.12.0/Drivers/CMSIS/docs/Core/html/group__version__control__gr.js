var group__version__control__gr =
[
    [ "Version Control per Core (Depricated)", "group__version__control__depricated__gr.html", "group__version__control__depricated__gr" ],
    [ "__CM_CMSIS_VERSION", "group__version__control__gr.html#ga39f3d64ff95fb58feccc7639e537ff89", null ],
    [ "__CM_CMSIS_VERSION_MAIN", "group__version__control__gr.html#ga85987c5fcc1e012d7ac01369ee6ca2b5", null ],
    [ "__CM_CMSIS_VERSION_SUB", "group__version__control__gr.html#ga22083cbe7f0606cfd538ec12b2e41608", null ],
    [ "__CORTEX_M", "group__version__control__gr.html#ga63ea62503c88acab19fcf3d5743009e3", null ],
    [ "__CORTEX_SC", "group__version__control__gr.html#gaeaaf66c86e5ae02a0e1fe542cb7f4d8c", null ]
];